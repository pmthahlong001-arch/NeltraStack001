package com.neltra.neltrastack;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class NeltraStack extends JavaPlugin {

    private static NeltraStack instance;
    private ItemStackManager stackManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        stackManager = new ItemStackManager(this);

        getServer().getPluginManager().registerEvents(new ItemDropListener(this), this);
        getServer().getPluginManager().registerEvents(new ItemPickupListener(this), this);
        getServer().getPluginManager().registerEvents(new ChunkLoadListener(this), this);

        getLogger().info("=================================");
        getLogger().info(" NeltraStack v1.0.0 enabled!");
        getLogger().info(" Stack multiplier: x" + getConfig().getInt("stack-multiplier", 10));
        getLogger().info(" Merge radius: " + getConfig().getDouble("merge-radius", 3.0) + " blocks");
        getLogger().info("=================================");
    }

    @Override
    public void onDisable() {
        getLogger().info("NeltraStack disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("neltrastack")) {
            if (!sender.hasPermission("neltrastack.admin")) {
                sender.sendMessage("§cBạn không có quyền dùng lệnh này!");
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                stackManager.reload();
                sender.sendMessage("§a[NeltraStack] §fĐã reload config!");
                return true;
            }
            sender.sendMessage("§a[NeltraStack] §fUsage: /neltrastack reload");
            return true;
        }
        return false;
    }

    public static NeltraStack getInstance() {
        return instance;
    }

    public ItemStackManager getStackManager() {
        return stackManager;
    }
}
