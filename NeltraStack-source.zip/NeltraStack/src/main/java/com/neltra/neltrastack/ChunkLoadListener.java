package com.neltra.neltrastack;

import org.bukkit.Chunk;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;

public class ChunkLoadListener implements Listener {

    private final NeltraStack plugin;

    public ChunkLoadListener(NeltraStack plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChunkLoad(ChunkLoadEvent event) {
        Chunk chunk = event.getChunk();

        plugin.getServer().getRegionScheduler().runDelayed(
            plugin,
            chunk.getWorld(),
            chunk.getX() << 4,
            chunk.getZ() << 4,
            task -> {
                for (Entity entity : chunk.getEntities()) {
                    if (!(entity instanceof Item item)) continue;
                    if (!item.isValid()) continue;
                    // Schedule tại đúng location của từng item để đúng region thread
                    plugin.getServer().getRegionScheduler().run(
                        plugin,
                        item.getLocation(),
                        t -> {
                            if (!item.isValid()) return;
                            if (plugin.getStackManager().isBlacklisted(item.getItemStack().getType())) return;
                            plugin.getStackManager().tryMerge(item);
                        }
                    );
                }
            },
            5L
        );
    }
}
