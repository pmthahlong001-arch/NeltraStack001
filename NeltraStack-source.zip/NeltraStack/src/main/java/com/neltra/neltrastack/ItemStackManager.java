package com.neltra.neltrastack;

import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.HashSet;
import java.util.Set;

public class ItemStackManager {

    private final NeltraStack plugin;
    private int stackMultiplier;
    private double mergeRadius;
    private int maxStackSize;
    private final Set<Material> blacklist = new HashSet<>();

    // Key để lưu số lượng thực tế vào NBT của item entity
    public static final String STACK_AMOUNT_KEY = "neltra_stack_amount";

    public ItemStackManager(NeltraStack plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        stackMultiplier = plugin.getConfig().getInt("stack-multiplier", 10);
        mergeRadius = plugin.getConfig().getDouble("merge-radius", 3.0);
        maxStackSize = plugin.getConfig().getInt("max-stack-size", 6400);
        blacklist.clear();
        for (String mat : plugin.getConfig().getStringList("blacklist")) {
            try {
                blacklist.add(Material.valueOf(mat.toUpperCase()));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Unknown material in blacklist: " + mat);
            }
        }
    }

    public boolean isBlacklisted(Material material) {
        return blacklist.contains(material);
    }

    /**
     * Lấy số lượng thực tế được lưu trong NBT của item entity.
     * Nếu không có NBT thì trả về số lượng mặc định của ItemStack.
     */
    public int getRealAmount(Item item) {
        NamespacedKey key = new NamespacedKey(plugin, STACK_AMOUNT_KEY);
        if (item.getPersistentDataContainer().has(key, PersistentDataType.INTEGER)) {
            return item.getPersistentDataContainer().get(key, PersistentDataType.INTEGER);
        }
        return item.getItemStack().getAmount();
    }

    /**
     * Lưu số lượng thực tế vào NBT của item entity.
     */
    public void setRealAmount(Item item, int amount) {
        NamespacedKey key = new NamespacedKey(plugin, STACK_AMOUNT_KEY);
        item.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, amount);
        // Hiển thị CustomName để player thấy số lượng
        updateDisplayName(item, amount);
    }

    /**
     * Cập nhật tên hiển thị của item entity để thấy số lượng.
     */
    public void updateDisplayName(Item item, int amount) {
        if (amount > item.getItemStack().getMaxStackSize()) {
            item.setCustomNameVisible(true);
            // Format tên: loại item x số lượng
            String matName = formatMaterialName(item.getItemStack().getType());
            item.customName(net.kyori.adventure.text.Component.text(
                "§e" + matName + " §6x" + amount
            ));
        } else {
            item.setCustomNameVisible(false);
            item.customName(null);
        }
    }

    /**
     * Thử gộp item mới drop vào item cùng loại gần đó.
     * Trả về true nếu đã gộp thành công (item mới nên bị xóa).
     */
    public boolean tryMerge(Item newItem) {
        if (isBlacklisted(newItem.getItemStack().getType())) return false;

        int newAmount = getRealAmount(newItem);

        for (org.bukkit.entity.Entity nearby : newItem.getNearbyEntities(mergeRadius, mergeRadius, mergeRadius)) {
            if (!(nearby instanceof Item existingItem)) continue;
            if (existingItem.equals(newItem)) continue;
            if (!existingItem.isValid()) continue;

            ItemStack existingStack = existingItem.getItemStack();
            ItemStack newStack = newItem.getItemStack();

            // Kiểm tra cùng loại item
            if (!isSimilar(existingStack, newStack)) continue;

            int existingAmount = getRealAmount(existingItem);
            int combined = existingAmount + newAmount;

            if (combined <= maxStackSize) {
                // Gộp toàn bộ vào item cũ
                setRealAmount(existingItem, combined);
                newItem.remove();
                return true;
            } else {
                // Gộp một phần cho đến khi đầy
                int canAdd = maxStackSize - existingAmount;
                if (canAdd > 0) {
                    setRealAmount(existingItem, maxStackSize);
                    newAmount -= canAdd;
                    setRealAmount(newItem, newAmount);
                }
            }
        }
        return false;
    }

    /**
     * Kiểm tra 2 ItemStack có giống nhau không (bỏ qua amount).
     */
    public boolean isSimilar(ItemStack a, ItemStack b) {
        if (a.getType() != b.getType()) return false;
        // Kiểm tra meta nếu có
        if (a.hasItemMeta() != b.hasItemMeta()) return false;
        if (a.hasItemMeta()) {
            return a.getItemMeta().equals(b.getItemMeta());
        }
        return true;
    }

    /**
     * Format tên Material cho đẹp.
     * Ví dụ: DIAMOND_SWORD -> Diamond Sword
     */
    private String formatMaterialName(Material material) {
        String[] words = material.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (!sb.isEmpty()) sb.append(" ");
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return sb.toString();
    }

    public int getStackMultiplier() { return stackMultiplier; }
    public double getMergeRadius() { return mergeRadius; }
    public int getMaxStackSize() { return maxStackSize; }
}
