package com.neltra.neltrastack;

import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.inventory.ItemStack;

public class ItemPickupListener implements Listener {

    private final NeltraStack plugin;

    public ItemPickupListener(NeltraStack plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        Item item = event.getItem();
        int realAmount = plugin.getStackManager().getRealAmount(item);
        int vanillaAmount = item.getItemStack().getAmount();

        // Nếu không có stacking thì bỏ qua
        if (realAmount <= vanillaAmount) return;

        // Cancel event mặc định, tự xử lý pickup
        event.setCancelled(true);

        ItemStack baseStack = item.getItemStack().clone();
        int maxPerSlot = baseStack.getMaxStackSize();
        int totalRemaining = realAmount;
        int totalGiven = 0;

        // Thêm từng stack vào inventory player
        while (totalRemaining > 0) {
            int toGive = Math.min(totalRemaining, maxPerSlot);
            ItemStack giving = baseStack.clone();
            giving.setAmount(toGive);

            java.util.HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(giving);

            if (leftover.isEmpty()) {
                // Thêm vào inventory thành công
                totalGiven += toGive;
                totalRemaining -= toGive;
            } else {
                // Inventory đầy - tính lại phần đã cho được
                int leftoverAmount = leftover.values().stream().mapToInt(ItemStack::getAmount).sum();
                int actualGiven = toGive - leftoverAmount;
                totalGiven += actualGiven;
                totalRemaining -= actualGiven;
                break; // Inventory đầy, dừng lại
            }
        }

        if (totalRemaining > 0) {
            // Drop lại phần không vào được inventory
            item.getItemStack().setAmount(Math.min(totalRemaining, maxPerSlot));
            plugin.getStackManager().setRealAmount(item, totalRemaining);
            item.setPickupDelay(40);
        } else {
            // Xóa item entity gốc
            item.remove();
        }

        if (totalGiven > 0) {
            // Pickup sound
            player.getWorld().playSound(
                player.getLocation(),
                org.bukkit.Sound.ENTITY_ITEM_PICKUP,
                0.2f,
                (float)(1.0 + Math.random() * 0.2)
            );
        }
    }
}
