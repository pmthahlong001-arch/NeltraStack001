#!/bin/bash
# Script build NeltraStack
# Yêu cầu: Java 21+, Maven 3.8+

echo "=== Building NeltraStack ==="
mvn clean package -q

if [ $? -eq 0 ]; then
    echo "✅ Build thành công!"
    echo "📦 File JAR: target/NeltraStack.jar"
    echo "👉 Copy vào thư mục plugins/ của Folia server"
else
    echo "❌ Build thất bại! Kiểm tra lỗi ở trên."
fi
